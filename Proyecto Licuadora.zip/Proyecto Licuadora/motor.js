var estadoLicuadora = "apagada";
var sonidoLicuadora = document.getElementById("blender-sound");
var botonLicuadora = document.getElementById ("blender-button-sound");
var licuadora = document.getElementById("blender"); 

// funcion hacer funcionar licuadora //
function controlarLicuadora() {
    if(estadoLicuadora == "apagada") { // Pregunta si el estado de la licuadora es apagado 
        estadoLicuadora = "encendido"; // cambia el estado a encendido 
        hacerBrrBrr();
        licuadora.classList.add("active");
        console.log("Encendida");
    } else {
        estadoLicuadora = "apagada" // si el estado de la licuadora es encendido la apaga
        hacerBrrBrr();
        licuadora.classList.remove("active");
        console.log("Apagada");
    }
}

// funcionamiento sonido //
function hacerBrrBrr() {
    if( sonidoLicuadora.paused ){
        botonLicuadora.play();
        sonidoLicuadora.play();
    } else {
        botonLicuadora.play();
        sonidoLicuadora.pause();
        sonidoLicuadora.currentTime = 0; /* Reinicia el audio al segundo 0 */
        }
    }